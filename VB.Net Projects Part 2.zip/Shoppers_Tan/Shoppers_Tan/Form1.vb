﻿'Project Name: Shoppers Haven Project
'Purpose: Calculate the Discounted Price
'Name: Robin Joshua L. Tan on October 18, 2016

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain

    Private Sub btnCal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCal.Click

        Dim dblOriginal As Double
        Dim dblRate As Double
        Dim dblDiscount As Double
        Dim dblDiscountPrice As Double

        Double.TryParse(txtOrigPrice.Text, dblOriginal)
        Double.TryParse(lstRate.SelectedItem.ToString, dblRate)

        dblDiscount = dblOriginal * dblRate / 100
        dblDiscountPrice = dblOriginal - dblDiscount
        lblDiscount.Text = "PHP" & dblDiscount.ToString("N2")
        lblDiscountPrice.Text = "PHP" & dblDiscountPrice.ToString("N2")

    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub frmMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        For dblRates As Double = 10 To 30 Step 5
            lstRate.Items.Add(dblRates.ToString)
        Next dblRates

        lstRate.SelectedIndex = 0
    End Sub

    Private Sub lstRate_SelectedValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles lstRate.SelectedValueChanged

        lblDiscount.Text = String.Empty
        lblDiscountPrice.Text = String.Empty
    End Sub

    Private Sub txtOrigPrice_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtOrigPrice.Enter

        txtOrigPrice.SelectAll()
    End Sub

    Private Sub txtOrigPrice_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtOrigPrice.KeyPress

        If (e.KeyChar < "0" OrElse e.KeyChar > "9") AndAlso
            e.KeyChar <> "." AndAlso
            e.KeyChar <> ControlChars.Back Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtOrigPrice_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtOrigPrice.TextChanged

        lblDiscount.Text = String.Empty
        lblDiscountPrice.Text = String.Empty
    End Sub

    Private Sub OpenToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenToolStripMenuItem.Click

    End Sub

    Private Sub SaveToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveToolStripMenuItem.Click

    End Sub

    Private Sub SaveAsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveAsToolStripMenuItem.Click

    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click

    End Sub

    Private Sub CopyToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CopyToolStripMenuItem.Click

    End Sub

    Private Sub UndoToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UndoToolStripMenuItem.Click

    End Sub

    Private Sub PageSetupToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PageSetupToolStripMenuItem.Click

    End Sub

    Private Sub PrintToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrintToolStripMenuItem1.Click

    End Sub

    Private Sub NewToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NewToolStripButton.Click

    End Sub

    Private Sub OpenToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenToolStripButton.Click

    End Sub

    Private Sub SaveToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveToolStripButton.Click

    End Sub

    Private Sub PrintToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrintToolStripButton.Click

    End Sub

    Private Sub CutToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CutToolStripButton.Click

    End Sub

    Private Sub CopyToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CopyToolStripButton.Click

    End Sub

    Private Sub PasteToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PasteToolStripButton.Click

    End Sub
End Class
