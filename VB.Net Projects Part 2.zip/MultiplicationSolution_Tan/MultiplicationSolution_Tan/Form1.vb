﻿'Program: Multiplication Application
'Purpose: Display Multiplication Table
'Programmer: Robin Joshua L. Tan on October 25, 2016

Option Infer Off
Option Strict On
Option Explicit On

Public Class Form1

    Private Sub btnDisplay_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDisplay.Click
        Dim dblFirst As Integer
        Dim dblSum As Integer

        Integer.TryParse(txtNum.Text, dblFirst)

        For dblSecondNum As Integer = 1 To 10 Step 1
            dblSum = dblFirst * dblSecondNum
            lblDisplay.Text += dblFirst.ToString() & "*" & dblSecondNum.ToString() & "=" & dblSum.ToString() & vbNewLine
        Next


    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub txtNum_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtNum.KeyPress
        lblDisplay.Text = String.Empty
    End Sub
End Class
