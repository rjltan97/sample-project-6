﻿'Program: Name Challenge
'Pupose: Sort Alphabetical Order
'Programmer: Robin Joshua L. Tan on 9/27/2016

Option Infer Off
Option Explicit On
Option Strict On

Public Class Form1

    Private Sub btnDisplay_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDisplay.Click


        If txtName.Text < txtName2.Text And txtName2.Text < txtName3.Text And txtName.Text < txtName3.Text Then
            lblDisplay.Text = txtName.Text.ToUpper & " " & txtName2.Text.ToUpper & " " & txtName3.Text.ToUpper

        ElseIf txtName2.Text < txtName.Text And txtName2.Text < txtName3.Text And txtName.Text < txtName3.Text Then
            lblDisplay.Text = txtName2.Text.ToUpper & " " & txtName.Text.ToUpper & " " & txtName3.Text.ToUpper

        ElseIf txtName3.Text < txtName2.Text And txtName3.Text < txtName.Text And txtName2.Text < txtName.Text Then
            lblDisplay.Text = txtName3.Text.ToUpper & " " & txtName2.Text.ToUpper & " " & txtName.Text.ToUpper

            '----------------------------------------------------------------------------------------------------'

        ElseIf txtName.Text < txtName3.Text And txtName.Text < txtName2.Text And txtName3.Text < txtName2.Text Then
            lblDisplay.Text = txtName.Text.ToUpper & " " & txtName3.Text.ToUpper & " " & txtName2.Text.ToUpper

        ElseIf txtName2.Text < txtName3.Text And txtName2.Text < txtName.Text And txtName3.Text < txtName.Text Then
            lblDisplay.Text = txtName2.Text.ToUpper & " " & txtName3.Text.ToUpper & " " & txtName.Text.ToUpper

        ElseIf txtName3.Text < txtName.Text And txtName3.Text < txtName2.Text And txtName.Text < txtName2.Text Then
            lblDisplay.Text = txtName3.Text.ToUpper & " " & txtName.Text.ToUpper & " " & txtName2.Text.ToUpper

        ElseIf txtName.Text = txtName2.Text Then
            lblDisplay.Text = "No 2 letters should be the same"

        ElseIf txtName2.Text = txtName3.Text Then
            lblDisplay.Text = "No 2 letters should be the same"

        ElseIf txtName.Text = txtName3.Text Then
            lblDisplay.Text = "No 2 letters should be the same"
        End If


    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
