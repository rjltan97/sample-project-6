﻿'Name: Grading System Project
'Purpose: Grading System
'Programmer: Robin Joshua L. Tan on September 20, 2016

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmGS

    Private Sub btnCal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCal.Click
        Dim decGrade As Decimal
        Decimal.TryParse(txtGrade.Text, decGrade)

        If decGrade = 1.0 Then
            lblRem.Text = "Excellent"
        ElseIf decGrade = 1.25 Then
            lblRem.Text = "Superior"
        ElseIf decGrade = 1.5 Then
            lblRem.Text = "Very Good"
        ElseIf decGrade = 1.75 Then
            lblRem.Text = "Above Average"
        ElseIf decGrade = 2.0 Then
            lblRem.Text = "Good"
        ElseIf decGrade = 2.25 Then
            lblRem.Text = "Average"
        ElseIf decGrade = 2.5 Then
            lblRem.Text = "Fair"
        ElseIf decGrade = 2.75 Then
            lblRem.Text = "Passing"
        ElseIf decGrade = 3.0 Then
            lblRem.Text = "Barely Passing"
        ElseIf decGrade = 4.0 OrElse decGrade = 5.0 Then
            lblRem.Text = "Failure"
        Else
            lblRem.Text = "Invalid Input/Grade"
        End If
    End Sub

    Private Sub btnExit2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit2.Click
        Me.Close()
    End Sub

    Private Sub txtGrade_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtGrade.TextChanged
        lblRem.Text = String.Empty
    End Sub

End Class
