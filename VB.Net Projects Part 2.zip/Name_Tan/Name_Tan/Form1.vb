﻿'Name: Name Project
'Purpose: Concatenates last name, comma, space, and first name
'Programmer: Robin Joshua L. Tan on September 6, 2016

Option Explicit On
Option Strict On
Option Infer Off

Public Class Form1
    Private strFirstName As String
    Private strLastName As String

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub


    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        strFirstName = InputBox("Enter your First Name: ", "First Name")
        strLastName = InputBox("Enter your Last Name: ", "Last Name")
    End Sub


    Private Sub btnDisplay_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDisplay.Click
        lblName.Text = strLastName & ", " & strFirstName
    End Sub
End Class
