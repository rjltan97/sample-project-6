﻿'Name: Grading System Project
'Purpose: Grading System
'Programmer: Robin Joshua L. Tan on September 20, 2016

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmLogIn

    Private Sub btnLogIn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLogIn.Click
        Dim strLetter As String
        Dim strPass As String
        strLetter = TxtUser.Text
        strPass = txtPass.Text

        If strLetter = "inte213" Then
            If strPass = "3ITSE01" Then
                frmGS.Visible = True
                Me.Close()
            End If
        Else
            TxtUser.Focus()
            TxtUser.Clear()
            txtPass.Clear()
        End If

    End Sub



End Class