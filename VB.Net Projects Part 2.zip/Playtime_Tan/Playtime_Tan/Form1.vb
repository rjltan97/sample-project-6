﻿'Name: Playtime Cellular Phone
'Purpose: Calculate the total number of phones and the prices
'Programmer: Robin Joshua L. Tan on September 6, 2016

Option Explicit On
Option Strict On
Option Infer Off

Public Class Form1

    Private Sub BtnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnExit.Click
        Me.Close()
    End Sub

    Private Sub BtnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnClear.Click
        TxtName.Text = String.Empty
        TxtAddress.Text = String.Empty
        TxtCity.Text = String.Empty
        TxtState.Text = String.Empty
        TxtZIP.Text = String.Empty
        TxtBluePhones.Text = String.Empty
        TxtPinkPhones.Text = String.Empty
        lblTotalPhones.Text = String.Empty
        lblTotalPrice.Text = String.Empty
        lblMessage.Text = String.Empty
        TxtName.Focus()

    End Sub

    Private Sub BtnCal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnCal.Click
        Const strPROMPT As String = "Salesperson's Name: "
        Const strTITLE As String = "Name Entry"
        Const decPHONE_PRICE As Decimal = 25D
        Const decTAX_RATE As Decimal = 0.03D
        Dim intBluePhones As Integer
        Dim intPinkPhones As Integer
        Dim intTotalPhones As Integer
        Dim decSubtotal As Decimal
        Dim decSalesTax As Decimal
        Dim decTotalPrice As Decimal
        Static strSalesPerson As String

        strSalesPerson = InputBox(strPROMPT, strTITLE, strSalesPerson)

        Integer.TryParse(TxtBluePhones.Text, intBluePhones)
        Integer.TryParse(TxtPinkPhones.Text, intPinkPhones)
        intTotalPhones = intBluePhones + intPinkPhones


        decSubtotal = intTotalPhones * decPHONE_PRICE
        decSalesTax = decSubtotal * decTAX_RATE
        decTotalPrice = decSubtotal + decSalesTax

        lblTotalPhones.Text = Convert.ToString(intTotalPhones)
        lblTotalPrice.Text = decTotalPrice.ToString("C2")

        lblMessage.Text = "The Sales tax was " &
            Convert.ToString(decSalesTax) &
            ControlChars.NewLine & strSalesPerson
    End Sub
    Private Sub ClearLabels(ByVal sender As Object, ByVal e As System.EventArgs) Handles TxtBluePhones.TextChanged, TxtPinkPhones.TextChanged

        lblTotalPhones.Text = String.Empty
        lblTotalPrice.Text = String.Empty
        lblMessage.Text = String.Empty

    End Sub

End Class
