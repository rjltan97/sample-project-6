﻿'Name: Jackets Unlimited'
'Purpose: Discount Calculation'
'Programmer: Robin Joshua L. Tan'
Public Class Form1

    Private Sub btnCal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCal.Click
        lblDAmt.Text = Val(txtOPrice.Text) * 0.25
        lblNAmt.Text = Val(txtOPrice.Text) - Val(lblDAmt.Text)
        lblNAmt.Text = Format(lblNAmt.Text, "Currency")
        lblDAmt.Text = Format(lblDAmt.Text, "Currency")
    End Sub


    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
