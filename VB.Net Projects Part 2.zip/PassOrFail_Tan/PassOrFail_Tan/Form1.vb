﻿'Name: Pass or Fail Project
'Purpose: Display either the Pass message or the Fail Message
'Programmer: Robin Joshua L. Tan on September 20, 2016

Option Explicit On
Option Strict On
Option Infer Off

Public Class Form1

    Private Sub btnDisplay_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDisplay.Click
        Dim strLetter As String
        strLetter = txtLetter.Text
        If strLetter = "P" OrElse strLetter = "p" Then
            lblMessage.Text = "Pass"
        ElseIf strLetter = "F" OrElse strLetter = "f" Then
            lblMessage.Text = "Fail"
        Else
            lblMessage.Text = "Invalid Letter"
        End If
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub txtLetter_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLetter.TextChanged
        lblMessage.Text = String.Empty
    End Sub
End Class
