﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.lblHeader = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.lblOP = New System.Windows.Forms.Label()
        Me.lblD = New System.Windows.Forms.Label()
        Me.lblNP = New System.Windows.Forms.Label()
        Me.txtOPrice = New System.Windows.Forms.TextBox()
        Me.lblDAmt = New System.Windows.Forms.Label()
        Me.lblNAmt = New System.Windows.Forms.Label()
        Me.btnCal = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblHeader
        '
        Me.lblHeader.AutoSize = True
        Me.lblHeader.BackColor = System.Drawing.Color.Transparent
        Me.lblHeader.Font = New System.Drawing.Font("Consolas", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHeader.Location = New System.Drawing.Point(58, 106)
        Me.lblHeader.Name = "lblHeader"
        Me.lblHeader.Size = New System.Drawing.Size(214, 24)
        Me.lblHeader.TabIndex = 0
        Me.lblHeader.Text = "JACKETS UNLIMITED"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(113, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(86, 91)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'lblOP
        '
        Me.lblOP.AutoSize = True
        Me.lblOP.BackColor = System.Drawing.Color.Transparent
        Me.lblOP.Font = New System.Drawing.Font("Consolas", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOP.Location = New System.Drawing.Point(23, 148)
        Me.lblOP.Name = "lblOP"
        Me.lblOP.Size = New System.Drawing.Size(135, 19)
        Me.lblOP.TabIndex = 2
        Me.lblOP.Text = "Original Price"
        '
        'lblD
        '
        Me.lblD.AutoSize = True
        Me.lblD.BackColor = System.Drawing.Color.Transparent
        Me.lblD.Font = New System.Drawing.Font("Consolas", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblD.Location = New System.Drawing.Point(23, 178)
        Me.lblD.Name = "lblD"
        Me.lblD.Size = New System.Drawing.Size(81, 19)
        Me.lblD.TabIndex = 3
        Me.lblD.Text = "Discount"
        '
        'lblNP
        '
        Me.lblNP.AutoSize = True
        Me.lblNP.BackColor = System.Drawing.Color.Transparent
        Me.lblNP.Font = New System.Drawing.Font("Consolas", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNP.Location = New System.Drawing.Point(23, 208)
        Me.lblNP.Name = "lblNP"
        Me.lblNP.Size = New System.Drawing.Size(90, 19)
        Me.lblNP.TabIndex = 4
        Me.lblNP.Text = "New Price"
        '
        'txtOPrice
        '
        Me.txtOPrice.Location = New System.Drawing.Point(195, 149)
        Me.txtOPrice.Name = "txtOPrice"
        Me.txtOPrice.Size = New System.Drawing.Size(77, 20)
        Me.txtOPrice.TabIndex = 5
        '
        'lblDAmt
        '
        Me.lblDAmt.BackColor = System.Drawing.Color.White
        Me.lblDAmt.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDAmt.Location = New System.Drawing.Point(195, 174)
        Me.lblDAmt.Name = "lblDAmt"
        Me.lblDAmt.Size = New System.Drawing.Size(77, 23)
        Me.lblDAmt.TabIndex = 6
        '
        'lblNAmt
        '
        Me.lblNAmt.BackColor = System.Drawing.Color.White
        Me.lblNAmt.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblNAmt.Location = New System.Drawing.Point(195, 208)
        Me.lblNAmt.Name = "lblNAmt"
        Me.lblNAmt.Size = New System.Drawing.Size(77, 23)
        Me.lblNAmt.TabIndex = 7
        '
        'btnCal
        '
        Me.btnCal.Location = New System.Drawing.Point(27, 251)
        Me.btnCal.Name = "btnCal"
        Me.btnCal.Size = New System.Drawing.Size(75, 23)
        Me.btnCal.TabIndex = 8
        Me.btnCal.Text = "&Calculate"
        Me.btnCal.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(238, 251)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 10
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Consolas", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(67, 293)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(180, 19)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "Robin Joshua L. Tan"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Consolas", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(127, 324)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(72, 19)
        Me.Label2.TabIndex = 12
        Me.Label2.Text = "3ITSE01"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Consolas", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(91, 343)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(135, 19)
        Me.Label3.TabIndex = 13
        Me.Label3.Text = "T/F 9:00-12:00"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Consolas", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(91, 372)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(144, 19)
        Me.Label4.TabIndex = 14
        Me.Label4.Text = "August 30, 2016"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(337, 400)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnCal)
        Me.Controls.Add(Me.lblNAmt)
        Me.Controls.Add(Me.lblDAmt)
        Me.Controls.Add(Me.txtOPrice)
        Me.Controls.Add(Me.lblNP)
        Me.Controls.Add(Me.lblD)
        Me.Controls.Add(Me.lblOP)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.lblHeader)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Jackets Unlimited"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblHeader As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents lblOP As System.Windows.Forms.Label
    Friend WithEvents lblD As System.Windows.Forms.Label
    Friend WithEvents lblNP As System.Windows.Forms.Label
    Friend WithEvents txtOPrice As System.Windows.Forms.TextBox
    Friend WithEvents lblDAmt As System.Windows.Forms.Label
    Friend WithEvents lblNAmt As System.Windows.Forms.Label
    Friend WithEvents btnCal As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label

End Class
