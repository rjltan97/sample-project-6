﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.lblHeader = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lblHValue = New System.Windows.Forms.Label()
        Me.lblTValue = New System.Windows.Forms.Label()
        Me.lblPValue = New System.Windows.Forms.Label()
        Me.lblTotalVersion = New System.Windows.Forms.Label()
        Me.lblTotalValue = New System.Windows.Forms.Label()
        Me.lblHardValue = New System.Windows.Forms.Label()
        Me.lblPaperValue = New System.Windows.Forms.Label()
        Me.lblTVersion = New System.Windows.Forms.Label()
        Me.BtnExit = New System.Windows.Forms.Button()
        Me.BtnClear = New System.Windows.Forms.Button()
        Me.btnCal = New System.Windows.Forms.Button()
        Me.TxtHCost = New System.Windows.Forms.TextBox()
        Me.TxtPCost = New System.Windows.Forms.TextBox()
        Me.txtHardVer = New System.Windows.Forms.TextBox()
        Me.txtPaperVer = New System.Windows.Forms.TextBox()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.lblHardCost = New System.Windows.Forms.Label()
        Me.lblPaperCost = New System.Windows.Forms.Label()
        Me.lblHardCover = New System.Windows.Forms.Label()
        Me.lblPaperBack = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(12, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(74, 72)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'lblHeader
        '
        Me.lblHeader.AutoSize = True
        Me.lblHeader.BackColor = System.Drawing.Color.Transparent
        Me.lblHeader.Font = New System.Drawing.Font("Century Gothic", 26.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHeader.Location = New System.Drawing.Point(75, 28)
        Me.lblHeader.Name = "lblHeader"
        Me.lblHeader.Size = New System.Drawing.Size(312, 42)
        Me.lblHeader.TabIndex = 1
        Me.lblHeader.Text = "BOOKWORM INC."
        '
        'Panel1
        '
        Me.Panel1.BackgroundImage = CType(resources.GetObject("Panel1.BackgroundImage"), System.Drawing.Image)
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.lblHValue)
        Me.Panel1.Controls.Add(Me.lblTValue)
        Me.Panel1.Controls.Add(Me.lblPValue)
        Me.Panel1.Controls.Add(Me.lblTotalVersion)
        Me.Panel1.Controls.Add(Me.lblTotalValue)
        Me.Panel1.Controls.Add(Me.lblHardValue)
        Me.Panel1.Controls.Add(Me.lblPaperValue)
        Me.Panel1.Controls.Add(Me.lblTVersion)
        Me.Panel1.Controls.Add(Me.BtnExit)
        Me.Panel1.Controls.Add(Me.BtnClear)
        Me.Panel1.Controls.Add(Me.btnCal)
        Me.Panel1.Controls.Add(Me.TxtHCost)
        Me.Panel1.Controls.Add(Me.TxtPCost)
        Me.Panel1.Controls.Add(Me.txtHardVer)
        Me.Panel1.Controls.Add(Me.txtPaperVer)
        Me.Panel1.Controls.Add(Me.txtName)
        Me.Panel1.Controls.Add(Me.lblHardCost)
        Me.Panel1.Controls.Add(Me.lblPaperCost)
        Me.Panel1.Controls.Add(Me.lblHardCover)
        Me.Panel1.Controls.Add(Me.lblPaperBack)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Location = New System.Drawing.Point(32, 106)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(468, 266)
        Me.Panel1.TabIndex = 4
        '
        'lblHValue
        '
        Me.lblHValue.BackColor = System.Drawing.Color.White
        Me.lblHValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblHValue.Location = New System.Drawing.Point(361, 130)
        Me.lblHValue.Name = "lblHValue"
        Me.lblHValue.Size = New System.Drawing.Size(48, 15)
        Me.lblHValue.TabIndex = 20
        Me.lblHValue.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblTValue
        '
        Me.lblTValue.BackColor = System.Drawing.Color.White
        Me.lblTValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTValue.Location = New System.Drawing.Point(142, 158)
        Me.lblTValue.Name = "lblTValue"
        Me.lblTValue.Size = New System.Drawing.Size(48, 15)
        Me.lblTValue.TabIndex = 19
        Me.lblTValue.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblPValue
        '
        Me.lblPValue.BackColor = System.Drawing.Color.White
        Me.lblPValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblPValue.Location = New System.Drawing.Point(142, 130)
        Me.lblPValue.Name = "lblPValue"
        Me.lblPValue.Size = New System.Drawing.Size(48, 15)
        Me.lblPValue.TabIndex = 18
        Me.lblPValue.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblTotalVersion
        '
        Me.lblTotalVersion.BackColor = System.Drawing.Color.White
        Me.lblTotalVersion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTotalVersion.Location = New System.Drawing.Point(142, 105)
        Me.lblTotalVersion.Name = "lblTotalVersion"
        Me.lblTotalVersion.Size = New System.Drawing.Size(48, 15)
        Me.lblTotalVersion.TabIndex = 17
        Me.lblTotalVersion.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblTotalValue
        '
        Me.lblTotalValue.AutoSize = True
        Me.lblTotalValue.BackColor = System.Drawing.Color.Transparent
        Me.lblTotalValue.Font = New System.Drawing.Font("Courier New", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalValue.Location = New System.Drawing.Point(16, 157)
        Me.lblTotalValue.Name = "lblTotalValue"
        Me.lblTotalValue.Size = New System.Drawing.Size(92, 16)
        Me.lblTotalValue.TabIndex = 16
        Me.lblTotalValue.Text = "Total Value:"
        '
        'lblHardValue
        '
        Me.lblHardValue.AutoSize = True
        Me.lblHardValue.BackColor = System.Drawing.Color.Transparent
        Me.lblHardValue.Font = New System.Drawing.Font("Courier New", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHardValue.Location = New System.Drawing.Point(235, 128)
        Me.lblHardValue.Name = "lblHardValue"
        Me.lblHardValue.Size = New System.Drawing.Size(120, 16)
        Me.lblHardValue.TabIndex = 15
        Me.lblHardValue.Text = "Hardcover Value:"
        '
        'lblPaperValue
        '
        Me.lblPaperValue.AutoSize = True
        Me.lblPaperValue.BackColor = System.Drawing.Color.Transparent
        Me.lblPaperValue.Font = New System.Drawing.Font("Courier New", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPaperValue.Location = New System.Drawing.Point(16, 129)
        Me.lblPaperValue.Name = "lblPaperValue"
        Me.lblPaperValue.Size = New System.Drawing.Size(120, 16)
        Me.lblPaperValue.TabIndex = 14
        Me.lblPaperValue.Text = "Paperback Value:"
        '
        'lblTVersion
        '
        Me.lblTVersion.AutoSize = True
        Me.lblTVersion.BackColor = System.Drawing.Color.Transparent
        Me.lblTVersion.Font = New System.Drawing.Font("Courier New", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTVersion.Location = New System.Drawing.Point(16, 104)
        Me.lblTVersion.Name = "lblTVersion"
        Me.lblTVersion.Size = New System.Drawing.Size(113, 16)
        Me.lblTVersion.TabIndex = 13
        Me.lblTVersion.Text = "Total Versions:"
        '
        'BtnExit
        '
        Me.BtnExit.Location = New System.Drawing.Point(338, 209)
        Me.BtnExit.Name = "BtnExit"
        Me.BtnExit.Size = New System.Drawing.Size(96, 24)
        Me.BtnExit.TabIndex = 12
        Me.BtnExit.Text = "E&xit"
        Me.BtnExit.UseVisualStyleBackColor = True
        '
        'BtnClear
        '
        Me.BtnClear.Location = New System.Drawing.Point(175, 209)
        Me.BtnClear.Name = "BtnClear"
        Me.BtnClear.Size = New System.Drawing.Size(96, 24)
        Me.BtnClear.TabIndex = 11
        Me.BtnClear.Text = "C&lear"
        Me.BtnClear.UseVisualStyleBackColor = True
        '
        'btnCal
        '
        Me.btnCal.Location = New System.Drawing.Point(19, 209)
        Me.btnCal.Name = "btnCal"
        Me.btnCal.Size = New System.Drawing.Size(96, 24)
        Me.btnCal.TabIndex = 10
        Me.btnCal.Text = "&Calculate"
        Me.btnCal.UseVisualStyleBackColor = True
        '
        'TxtHCost
        '
        Me.TxtHCost.Location = New System.Drawing.Point(388, 72)
        Me.TxtHCost.Name = "TxtHCost"
        Me.TxtHCost.Size = New System.Drawing.Size(46, 20)
        Me.TxtHCost.TabIndex = 4
        '
        'TxtPCost
        '
        Me.TxtPCost.Location = New System.Drawing.Point(388, 44)
        Me.TxtPCost.Name = "TxtPCost"
        Me.TxtPCost.Size = New System.Drawing.Size(46, 20)
        Me.TxtPCost.TabIndex = 2
        '
        'txtHardVer
        '
        Me.txtHardVer.Location = New System.Drawing.Point(163, 72)
        Me.txtHardVer.Name = "txtHardVer"
        Me.txtHardVer.Size = New System.Drawing.Size(46, 20)
        Me.txtHardVer.TabIndex = 3
        '
        'txtPaperVer
        '
        Me.txtPaperVer.Location = New System.Drawing.Point(163, 44)
        Me.txtPaperVer.Name = "txtPaperVer"
        Me.txtPaperVer.Size = New System.Drawing.Size(46, 20)
        Me.txtPaperVer.TabIndex = 1
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(100, 13)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(243, 20)
        Me.txtName.TabIndex = 0
        '
        'lblHardCost
        '
        Me.lblHardCost.AutoSize = True
        Me.lblHardCost.BackColor = System.Drawing.Color.Transparent
        Me.lblHardCost.Font = New System.Drawing.Font("Courier New", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHardCost.Location = New System.Drawing.Point(269, 74)
        Me.lblHardCost.Name = "lblHardCost"
        Me.lblHardCost.Size = New System.Drawing.Size(113, 16)
        Me.lblHardCost.TabIndex = 4
        Me.lblHardCost.Text = "Hardcover Cost:"
        '
        'lblPaperCost
        '
        Me.lblPaperCost.AutoSize = True
        Me.lblPaperCost.BackColor = System.Drawing.Color.Transparent
        Me.lblPaperCost.Font = New System.Drawing.Font("Courier New", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPaperCost.Location = New System.Drawing.Point(269, 46)
        Me.lblPaperCost.Name = "lblPaperCost"
        Me.lblPaperCost.Size = New System.Drawing.Size(113, 16)
        Me.lblPaperCost.TabIndex = 3
        Me.lblPaperCost.Text = "Paperback Cost:"
        '
        'lblHardCover
        '
        Me.lblHardCover.AutoSize = True
        Me.lblHardCover.BackColor = System.Drawing.Color.Transparent
        Me.lblHardCover.Font = New System.Drawing.Font("Courier New", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHardCover.Location = New System.Drawing.Point(16, 74)
        Me.lblHardCover.Name = "lblHardCover"
        Me.lblHardCover.Size = New System.Drawing.Size(141, 16)
        Me.lblHardCover.TabIndex = 2
        Me.lblHardCover.Text = "Hardcover Versions:"
        '
        'lblPaperBack
        '
        Me.lblPaperBack.AutoSize = True
        Me.lblPaperBack.BackColor = System.Drawing.Color.Transparent
        Me.lblPaperBack.Font = New System.Drawing.Font("Courier New", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPaperBack.Location = New System.Drawing.Point(16, 46)
        Me.lblPaperBack.Name = "lblPaperBack"
        Me.lblPaperBack.Size = New System.Drawing.Size(141, 16)
        Me.lblPaperBack.TabIndex = 1
        Me.lblPaperBack.Text = "Paperback Versions:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Courier New", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(16, 17)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(78, 16)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Book Name:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Courier New", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(8, 390)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(141, 16)
        Me.Label1.TabIndex = 21
        Me.Label1.Text = "Robin Joshua L. Tan"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Courier New", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(155, 390)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(57, 16)
        Me.Label2.TabIndex = 22
        Me.Label2.Text = "3ITSE01"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Courier New", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(243, 390)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(134, 16)
        Me.Label4.TabIndex = 23
        Me.Label4.Text = "T/F 9:00am-12:00pm"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Courier New", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(392, 390)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(113, 16)
        Me.Label5.TabIndex = 24
        Me.Label5.Text = "AUGUST 30, 2016"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(532, 415)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.lblHeader)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Bookworm Application"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents lblHeader As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents lblHardCost As System.Windows.Forms.Label
    Friend WithEvents lblPaperCost As System.Windows.Forms.Label
    Friend WithEvents lblHardCover As System.Windows.Forms.Label
    Friend WithEvents lblPaperBack As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TxtHCost As System.Windows.Forms.TextBox
    Friend WithEvents TxtPCost As System.Windows.Forms.TextBox
    Friend WithEvents txtHardVer As System.Windows.Forms.TextBox
    Friend WithEvents txtPaperVer As System.Windows.Forms.TextBox
    Friend WithEvents txtName As System.Windows.Forms.TextBox
    Friend WithEvents lblTValue As System.Windows.Forms.Label
    Friend WithEvents lblPValue As System.Windows.Forms.Label
    Friend WithEvents lblTotalVersion As System.Windows.Forms.Label
    Friend WithEvents lblTotalValue As System.Windows.Forms.Label
    Friend WithEvents lblHardValue As System.Windows.Forms.Label
    Friend WithEvents lblPaperValue As System.Windows.Forms.Label
    Friend WithEvents lblTVersion As System.Windows.Forms.Label
    Friend WithEvents BtnExit As System.Windows.Forms.Button
    Friend WithEvents BtnClear As System.Windows.Forms.Button
    Friend WithEvents btnCal As System.Windows.Forms.Button
    Friend WithEvents lblHValue As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label

End Class
