﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Frm1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Frm1))
        Me.Pan1 = New System.Windows.Forms.Panel()
        Me.lblMessage = New System.Windows.Forms.Label()
        Me.lblNewPay = New System.Windows.Forms.Label()
        Me.TxtOP1 = New System.Windows.Forms.TextBox()
        Me.TxtOP2 = New System.Windows.Forms.TextBox()
        Me.TxtOP3 = New System.Windows.Forms.TextBox()
        Me.btnCal = New System.Windows.Forms.Button()
        Me.BtnExit = New System.Windows.Forms.Button()
        Me.lblCrnt1 = New System.Windows.Forms.Label()
        Me.lblCrnt2 = New System.Windows.Forms.Label()
        Me.lblCrnt3 = New System.Windows.Forms.Label()
        Me.lblInstruction = New System.Windows.Forms.Label()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Pan1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Pan1
        '
        Me.Pan1.BackgroundImage = CType(resources.GetObject("Pan1.BackgroundImage"), System.Drawing.Image)
        Me.Pan1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Pan1.Controls.Add(Me.lblMessage)
        Me.Pan1.Controls.Add(Me.lblNewPay)
        Me.Pan1.Location = New System.Drawing.Point(12, 214)
        Me.Pan1.Name = "Pan1"
        Me.Pan1.Size = New System.Drawing.Size(613, 187)
        Me.Pan1.TabIndex = 0
        '
        'lblMessage
        '
        Me.lblMessage.AutoSize = True
        Me.lblMessage.BackColor = System.Drawing.Color.Transparent
        Me.lblMessage.Font = New System.Drawing.Font("Consolas", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMessage.Location = New System.Drawing.Point(131, 148)
        Me.lblMessage.Name = "lblMessage"
        Me.lblMessage.Size = New System.Drawing.Size(0, 19)
        Me.lblMessage.TabIndex = 1
        Me.lblMessage.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblNewPay
        '
        Me.lblNewPay.AutoSize = True
        Me.lblNewPay.BackColor = System.Drawing.Color.Transparent
        Me.lblNewPay.Font = New System.Drawing.Font("Consolas", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNewPay.Location = New System.Drawing.Point(130, 27)
        Me.lblNewPay.Name = "lblNewPay"
        Me.lblNewPay.Size = New System.Drawing.Size(0, 28)
        Me.lblNewPay.TabIndex = 0
        Me.lblNewPay.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'TxtOP1
        '
        Me.TxtOP1.Location = New System.Drawing.Point(61, 142)
        Me.TxtOP1.Name = "TxtOP1"
        Me.TxtOP1.Size = New System.Drawing.Size(81, 22)
        Me.TxtOP1.TabIndex = 1
        '
        'TxtOP2
        '
        Me.TxtOP2.Location = New System.Drawing.Point(272, 142)
        Me.TxtOP2.Name = "TxtOP2"
        Me.TxtOP2.Size = New System.Drawing.Size(81, 22)
        Me.TxtOP2.TabIndex = 2
        '
        'TxtOP3
        '
        Me.TxtOP3.Location = New System.Drawing.Point(488, 142)
        Me.TxtOP3.Name = "TxtOP3"
        Me.TxtOP3.Size = New System.Drawing.Size(81, 22)
        Me.TxtOP3.TabIndex = 3
        '
        'btnCal
        '
        Me.btnCal.Location = New System.Drawing.Point(222, 183)
        Me.btnCal.Name = "btnCal"
        Me.btnCal.Size = New System.Drawing.Size(87, 25)
        Me.btnCal.TabIndex = 4
        Me.btnCal.Text = "&Calculate"
        Me.btnCal.UseVisualStyleBackColor = True
        '
        'BtnExit
        '
        Me.BtnExit.Location = New System.Drawing.Point(315, 183)
        Me.BtnExit.Name = "BtnExit"
        Me.BtnExit.Size = New System.Drawing.Size(87, 25)
        Me.BtnExit.TabIndex = 5
        Me.BtnExit.Text = "E&xit"
        Me.BtnExit.UseVisualStyleBackColor = True
        '
        'lblCrnt1
        '
        Me.lblCrnt1.AutoSize = True
        Me.lblCrnt1.BackColor = System.Drawing.Color.Transparent
        Me.lblCrnt1.Font = New System.Drawing.Font("Consolas", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCrnt1.Location = New System.Drawing.Point(57, 125)
        Me.lblCrnt1.Name = "lblCrnt1"
        Me.lblCrnt1.Size = New System.Drawing.Size(77, 14)
        Me.lblCrnt1.TabIndex = 6
        Me.lblCrnt1.Text = "Job Code 1"
        '
        'lblCrnt2
        '
        Me.lblCrnt2.AutoSize = True
        Me.lblCrnt2.BackColor = System.Drawing.Color.Transparent
        Me.lblCrnt2.Font = New System.Drawing.Font("Consolas", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCrnt2.Location = New System.Drawing.Point(268, 125)
        Me.lblCrnt2.Name = "lblCrnt2"
        Me.lblCrnt2.Size = New System.Drawing.Size(77, 14)
        Me.lblCrnt2.TabIndex = 7
        Me.lblCrnt2.Text = "Job Code 2"
        '
        'lblCrnt3
        '
        Me.lblCrnt3.AutoSize = True
        Me.lblCrnt3.BackColor = System.Drawing.Color.Transparent
        Me.lblCrnt3.Font = New System.Drawing.Font("Consolas", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCrnt3.Location = New System.Drawing.Point(484, 125)
        Me.lblCrnt3.Name = "lblCrnt3"
        Me.lblCrnt3.Size = New System.Drawing.Size(77, 14)
        Me.lblCrnt3.TabIndex = 8
        Me.lblCrnt3.Text = "Job Code 3"
        '
        'lblInstruction
        '
        Me.lblInstruction.BackColor = System.Drawing.Color.Transparent
        Me.lblInstruction.Font = New System.Drawing.Font("Consolas", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInstruction.Location = New System.Drawing.Point(143, 90)
        Me.lblInstruction.Name = "lblInstruction"
        Me.lblInstruction.Size = New System.Drawing.Size(341, 25)
        Me.lblInstruction.TabIndex = 9
        Me.lblInstruction.Text = "ENTER CURRENT HOURLY PAY"
        Me.lblInstruction.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblTitle.Font = New System.Drawing.Font("High Tower Text", 27.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.Location = New System.Drawing.Point(99, 12)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(383, 44)
        Me.lblTitle.TabIndex = 10
        Me.lblTitle.Text = "PAY APPLICATION"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(12, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(81, 79)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 11
        Me.PictureBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Location = New System.Drawing.Point(12, 414)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(140, 14)
        Me.Label1.TabIndex = 12
        Me.Label1.Text = "Robin Joshua L. Tan"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Location = New System.Drawing.Point(219, 414)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(56, 14)
        Me.Label2.TabIndex = 13
        Me.Label2.Text = "3ITSE01"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Location = New System.Drawing.Point(337, 414)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(105, 14)
        Me.Label3.TabIndex = 14
        Me.Label3.Text = "T/F 9:00-12:00"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Location = New System.Drawing.Point(485, 414)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(133, 14)
        Me.Label4.TabIndex = 15
        Me.Label4.Text = "September 13, 2016"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Frm1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 14.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(637, 437)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.lblInstruction)
        Me.Controls.Add(Me.lblCrnt3)
        Me.Controls.Add(Me.lblCrnt2)
        Me.Controls.Add(Me.lblCrnt1)
        Me.Controls.Add(Me.BtnExit)
        Me.Controls.Add(Me.btnCal)
        Me.Controls.Add(Me.TxtOP3)
        Me.Controls.Add(Me.TxtOP2)
        Me.Controls.Add(Me.TxtOP1)
        Me.Controls.Add(Me.Pan1)
        Me.Font = New System.Drawing.Font("Consolas", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "Frm1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Pay Application"
        Me.Pan1.ResumeLayout(False)
        Me.Pan1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Pan1 As System.Windows.Forms.Panel
    Friend WithEvents TxtOP1 As System.Windows.Forms.TextBox
    Friend WithEvents TxtOP2 As System.Windows.Forms.TextBox
    Friend WithEvents TxtOP3 As System.Windows.Forms.TextBox
    Friend WithEvents btnCal As System.Windows.Forms.Button
    Friend WithEvents BtnExit As System.Windows.Forms.Button
    Friend WithEvents lblCrnt1 As System.Windows.Forms.Label
    Friend WithEvents lblCrnt2 As System.Windows.Forms.Label
    Friend WithEvents lblCrnt3 As System.Windows.Forms.Label
    Friend WithEvents lblInstruction As System.Windows.Forms.Label
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents lblNewPay As System.Windows.Forms.Label
    Friend WithEvents lblMessage As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label

End Class
