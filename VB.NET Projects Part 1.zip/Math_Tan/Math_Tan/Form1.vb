﻿'Program: Math Application
'Purpose: Adds and Subtracts Numbers
'Programmer: Robin Joshua L. Tan on 10/11/2016

Option Infer Off
Option Strict On
Option Explicit On

Public Class frmMain

    Private Sub btnCheck_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCheck.Click
        Dim UserAns As Integer
        Dim Num1 As Integer
        Dim Num2 As Integer
        Dim CorrectAns As Integer
        Static CorrRes As Integer
        Static IncRes As Integer

        Integer.TryParse(lblRndm1.Text, Num1)
        Integer.TryParse(lblRndm2.Text, Num2)
        Integer.TryParse(txtAns.Text, UserAns)

        Select Case True
            Case rdAddition.Checked
                CorrectAns = Num1 + Num2
            Case Else
                CorrectAns = Num1 - Num2
        End Select

        If UserAns = CorrectAns Then
            pbResult.Image = pbSmile.Image
            CorrRes = CorrRes + 1
            txtAns.Text = String.Empty
            Call GenerateandDisplayIntegers()
        Else
            pbResult.Image = pbSad.Image
            IncRes = IncRes + 1
            txtAns.SelectAll()
        End If

        txtAns.Text = ""
        txtAns.Focus()
        lblCorrect.Text = CorrRes.ToString
        lblIncorrect.Text = IncRes.ToString
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub chkSummary_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkSummary.CheckedChanged
        If chkSummary.Checked = False Then
            grpSummary.Visible = False
        Else
            grpSummary.Visible = True
        End If
    End Sub

    Private Sub rdGrade1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdGrade1.CheckedChanged
        Call GenerateandDisplayIntegers()
    End Sub

    Private Sub rdGrade2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdGrade2.CheckedChanged
        Call GenerateandDisplayIntegers()
    End Sub

    Private Sub GenerateandDisplayIntegers()
        Dim intRandom1 As New Integer
        Dim intRandom2 As New Integer
        Dim RandomGenerator As New Random

        If rdGrade1.Checked Then
            intRandom1 = RandomGenerator.Next(1, 11)
            intRandom2 = RandomGenerator.Next(1, 11)
        Else
            intRandom1 = RandomGenerator.Next(10, 100)
            intRandom2 = RandomGenerator.Next(10, 100)
        End If

        If rdSubtraction.Checked AndAlso intRandom1 < intRandom2 Then
            Dim intTemp As Integer
            intTemp = intRandom1
            intRandom1 = intRandom2
            intRandom2 = intTemp
        End If

        lblRndm1.Text = intRandom1.ToString()
        lblRndm2.Text = intRandom2.ToString()


    End Sub

    Private Sub rdAddition_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdAddition.Click
        Call GenerateandDisplayIntegers()
        pbOperation.Image = pbPlus.Image
        txtAns.Clear()
    End Sub

    Private Sub rdSubtraction_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdSubtraction.Click
        Call GenerateandDisplayIntegers()
        pbOperation.Image = pbMinus.Image
        txtAns.Clear()
    End Sub

    Private Sub frmMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        rdAddition.PerformClick()
        rdGrade1.PerformClick()
    End Sub
End Class
