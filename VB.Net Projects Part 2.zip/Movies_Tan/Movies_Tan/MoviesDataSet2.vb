﻿Partial Class MoviesDataSet
End Class

Namespace MoviesDataSetTableAdapters
    
    Partial Public Class tblMoviesTableAdapter
    End Class
End Namespace
