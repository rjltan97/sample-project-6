﻿'Program: Sports Club
'Purpose: Display Record
'Programmer: Robin Joshua L. Tan on 11/15/2016

Option Explicit On
Option Infer Off
Option Strict On

Public Class FrmMain

    Private Sub FrmMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.TblScoresTableAdapter.Fill(Me.SportsDataSet.tblScores)
    End Sub
End Class
