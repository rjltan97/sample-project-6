﻿'Name: Pay Application 
'Purpose: Calculate Hourly Pay
'Programmer:Robin Joshua L. Tan

Option Explicit On
Option Infer Off
Option Strict On

Public Class Frm1

    Private dblRaiseRate As Double

    Private Sub Frm1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim strMessage As String
        strMessage = InputBox("Raise Rate (Example, 0.05)", "Percentage")
        Double.TryParse(strMessage, dblRaiseRate)
    End Sub

    Private Sub btnCal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCal.Click
        Const strDisplay As String = "Raise Percentage is: "
        Dim dblOldPay1 As Double
        Dim dblOldPay2 As Double
        Dim dblOldPay3 As Double
        Dim dblNewPay1 As Double
        Dim dblNewPay2 As Double
        Dim dblNewPay3 As Double

        Double.TryParse(TxtOP1.Text, dblOldPay1)
        Double.TryParse(TxtOP2.Text, dblOldPay2)
        Double.TryParse(TxtOP3.Text, dblOldPay3)

        dblNewPay1 = dblOldPay1 * dblRaiseRate + dblOldPay1
        dblNewPay2 = dblOldPay2 * dblRaiseRate + dblOldPay2
        dblNewPay3 = dblOldPay3 * dblRaiseRate + dblOldPay3

        lblNewPay.Text = "New Pay for Job Code 1: " & dblNewPay1.ToString("N2") &
         ControlChars.NewLine & "New Pay for Job Code 2: " & dblNewPay2.ToString("N2") &
         ControlChars.NewLine & "New Pay for Job Code 3: " & dblNewPay3.ToString("N2")

        lblMessage.Text = strDisplay & dblRaiseRate.ToString("P0")

        TxtOP1.Focus()


    End Sub

    Private Sub BtnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnExit.Click
        Me.Close()
    End Sub
End Class
