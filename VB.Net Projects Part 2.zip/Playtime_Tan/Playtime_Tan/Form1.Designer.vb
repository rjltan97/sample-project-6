﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.BtnCal = New System.Windows.Forms.Button()
        Me.BtnClear = New System.Windows.Forms.Button()
        Me.BtnExit = New System.Windows.Forms.Button()
        Me.TxtName = New System.Windows.Forms.TextBox()
        Me.TxtAddress = New System.Windows.Forms.TextBox()
        Me.TxtCity = New System.Windows.Forms.TextBox()
        Me.TxtState = New System.Windows.Forms.TextBox()
        Me.TxtZIP = New System.Windows.Forms.TextBox()
        Me.TxtBluePhones = New System.Windows.Forms.TextBox()
        Me.TxtPinkPhones = New System.Windows.Forms.TextBox()
        Me.lblHeader = New System.Windows.Forms.Label()
        Me.lblName = New System.Windows.Forms.Label()
        Me.lblAddress = New System.Windows.Forms.Label()
        Me.lblCity = New System.Windows.Forms.Label()
        Me.lblState = New System.Windows.Forms.Label()
        Me.lblZIP = New System.Windows.Forms.Label()
        Me.lblTotalPriceN = New System.Windows.Forms.Label()
        Me.lblBluePhones = New System.Windows.Forms.Label()
        Me.lblPinkPhones = New System.Windows.Forms.Label()
        Me.lblTotalPhonesN = New System.Windows.Forms.Label()
        Me.lblTotalPhones = New System.Windows.Forms.Label()
        Me.lblTotalPrice = New System.Windows.Forms.Label()
        Me.Pb1 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Pan1 = New System.Windows.Forms.Panel()
        Me.lblMessage = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        CType(Me.Pb1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Pan1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'BtnCal
        '
        Me.BtnCal.Location = New System.Drawing.Point(17, 17)
        Me.BtnCal.Name = "BtnCal"
        Me.BtnCal.Size = New System.Drawing.Size(138, 23)
        Me.BtnCal.TabIndex = 7
        Me.BtnCal.Text = "&Calculate Order"
        Me.BtnCal.UseVisualStyleBackColor = True
        '
        'BtnClear
        '
        Me.BtnClear.Location = New System.Drawing.Point(17, 46)
        Me.BtnClear.Name = "BtnClear"
        Me.BtnClear.Size = New System.Drawing.Size(138, 23)
        Me.BtnClear.TabIndex = 8
        Me.BtnClear.Text = "C&lear Screen"
        Me.BtnClear.UseVisualStyleBackColor = True
        '
        'BtnExit
        '
        Me.BtnExit.Location = New System.Drawing.Point(17, 95)
        Me.BtnExit.Name = "BtnExit"
        Me.BtnExit.Size = New System.Drawing.Size(138, 23)
        Me.BtnExit.TabIndex = 9
        Me.BtnExit.Text = "E&xit"
        Me.BtnExit.UseVisualStyleBackColor = True
        '
        'TxtName
        '
        Me.TxtName.Location = New System.Drawing.Point(86, 17)
        Me.TxtName.Name = "TxtName"
        Me.TxtName.Size = New System.Drawing.Size(143, 20)
        Me.TxtName.TabIndex = 0
        '
        'TxtAddress
        '
        Me.TxtAddress.Location = New System.Drawing.Point(86, 43)
        Me.TxtAddress.Name = "TxtAddress"
        Me.TxtAddress.Size = New System.Drawing.Size(143, 20)
        Me.TxtAddress.TabIndex = 1
        '
        'TxtCity
        '
        Me.TxtCity.Location = New System.Drawing.Point(86, 69)
        Me.TxtCity.Name = "TxtCity"
        Me.TxtCity.Size = New System.Drawing.Size(143, 20)
        Me.TxtCity.TabIndex = 2
        '
        'TxtState
        '
        Me.TxtState.Location = New System.Drawing.Point(86, 95)
        Me.TxtState.Name = "TxtState"
        Me.TxtState.Size = New System.Drawing.Size(63, 20)
        Me.TxtState.TabIndex = 3
        '
        'TxtZIP
        '
        Me.TxtZIP.Location = New System.Drawing.Point(226, 95)
        Me.TxtZIP.Name = "TxtZIP"
        Me.TxtZIP.Size = New System.Drawing.Size(63, 20)
        Me.TxtZIP.TabIndex = 4
        '
        'TxtBluePhones
        '
        Me.TxtBluePhones.BackColor = System.Drawing.Color.LightCyan
        Me.TxtBluePhones.Location = New System.Drawing.Point(177, 228)
        Me.TxtBluePhones.Name = "TxtBluePhones"
        Me.TxtBluePhones.Size = New System.Drawing.Size(36, 20)
        Me.TxtBluePhones.TabIndex = 5
        '
        'TxtPinkPhones
        '
        Me.TxtPinkPhones.BackColor = System.Drawing.Color.LavenderBlush
        Me.TxtPinkPhones.Location = New System.Drawing.Point(177, 251)
        Me.TxtPinkPhones.Name = "TxtPinkPhones"
        Me.TxtPinkPhones.Size = New System.Drawing.Size(36, 20)
        Me.TxtPinkPhones.TabIndex = 6
        '
        'lblHeader
        '
        Me.lblHeader.AutoSize = True
        Me.lblHeader.BackColor = System.Drawing.Color.Transparent
        Me.lblHeader.Font = New System.Drawing.Font("Verdana", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHeader.Location = New System.Drawing.Point(108, 25)
        Me.lblHeader.Name = "lblHeader"
        Me.lblHeader.Size = New System.Drawing.Size(352, 25)
        Me.lblHeader.TabIndex = 11
        Me.lblHeader.Text = "Playtime Cellular Order Form"
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.BackColor = System.Drawing.Color.Transparent
        Me.lblName.Font = New System.Drawing.Font("Trebuchet MS", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblName.Location = New System.Drawing.Point(27, 17)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(42, 18)
        Me.lblName.TabIndex = 0
        Me.lblName.Text = "Name"
        '
        'lblAddress
        '
        Me.lblAddress.AutoSize = True
        Me.lblAddress.BackColor = System.Drawing.Color.Transparent
        Me.lblAddress.Font = New System.Drawing.Font("Trebuchet MS", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAddress.Location = New System.Drawing.Point(27, 43)
        Me.lblAddress.Name = "lblAddress"
        Me.lblAddress.Size = New System.Drawing.Size(57, 18)
        Me.lblAddress.TabIndex = 1
        Me.lblAddress.Text = "Address"
        '
        'lblCity
        '
        Me.lblCity.AutoSize = True
        Me.lblCity.BackColor = System.Drawing.Color.Transparent
        Me.lblCity.Font = New System.Drawing.Font("Trebuchet MS", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCity.Location = New System.Drawing.Point(27, 69)
        Me.lblCity.Name = "lblCity"
        Me.lblCity.Size = New System.Drawing.Size(32, 18)
        Me.lblCity.TabIndex = 2
        Me.lblCity.Text = "City"
        '
        'lblState
        '
        Me.lblState.AutoSize = True
        Me.lblState.BackColor = System.Drawing.Color.Transparent
        Me.lblState.Font = New System.Drawing.Font("Trebuchet MS", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblState.Location = New System.Drawing.Point(27, 95)
        Me.lblState.Name = "lblState"
        Me.lblState.Size = New System.Drawing.Size(39, 18)
        Me.lblState.TabIndex = 15
        Me.lblState.Text = "State"
        '
        'lblZIP
        '
        Me.lblZIP.AutoSize = True
        Me.lblZIP.BackColor = System.Drawing.Color.Transparent
        Me.lblZIP.Font = New System.Drawing.Font("Trebuchet MS", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblZIP.Location = New System.Drawing.Point(193, 95)
        Me.lblZIP.Name = "lblZIP"
        Me.lblZIP.Size = New System.Drawing.Size(27, 18)
        Me.lblZIP.TabIndex = 16
        Me.lblZIP.Text = "ZIP"
        '
        'lblTotalPriceN
        '
        Me.lblTotalPriceN.AutoSize = True
        Me.lblTotalPriceN.BackColor = System.Drawing.Color.Transparent
        Me.lblTotalPriceN.Font = New System.Drawing.Font("Trebuchet MS", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalPriceN.Location = New System.Drawing.Point(414, 254)
        Me.lblTotalPriceN.Name = "lblTotalPriceN"
        Me.lblTotalPriceN.Size = New System.Drawing.Size(75, 18)
        Me.lblTotalPriceN.TabIndex = 17
        Me.lblTotalPriceN.Text = "Total Price"
        '
        'lblBluePhones
        '
        Me.lblBluePhones.AutoSize = True
        Me.lblBluePhones.BackColor = System.Drawing.Color.Transparent
        Me.lblBluePhones.Font = New System.Drawing.Font("Trebuchet MS", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBluePhones.Location = New System.Drawing.Point(33, 228)
        Me.lblBluePhones.Name = "lblBluePhones"
        Me.lblBluePhones.Size = New System.Drawing.Size(138, 18)
        Me.lblBluePhones.TabIndex = 18
        Me.lblBluePhones.Text = "Blue Phones Ordered"
        '
        'lblPinkPhones
        '
        Me.lblPinkPhones.AutoSize = True
        Me.lblPinkPhones.BackColor = System.Drawing.Color.Transparent
        Me.lblPinkPhones.Font = New System.Drawing.Font("Trebuchet MS", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPinkPhones.Location = New System.Drawing.Point(33, 254)
        Me.lblPinkPhones.Name = "lblPinkPhones"
        Me.lblPinkPhones.Size = New System.Drawing.Size(138, 18)
        Me.lblPinkPhones.TabIndex = 19
        Me.lblPinkPhones.Text = "Pink Phones Ordered"
        '
        'lblTotalPhonesN
        '
        Me.lblTotalPhonesN.AutoSize = True
        Me.lblTotalPhonesN.BackColor = System.Drawing.Color.Transparent
        Me.lblTotalPhonesN.Font = New System.Drawing.Font("Trebuchet MS", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalPhonesN.Location = New System.Drawing.Point(414, 228)
        Me.lblTotalPhonesN.Name = "lblTotalPhonesN"
        Me.lblTotalPhonesN.Size = New System.Drawing.Size(87, 18)
        Me.lblTotalPhonesN.TabIndex = 20
        Me.lblTotalPhonesN.Text = "Total Phones"
        '
        'lblTotalPhones
        '
        Me.lblTotalPhones.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.lblTotalPhones.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTotalPhones.Location = New System.Drawing.Point(508, 228)
        Me.lblTotalPhones.Name = "lblTotalPhones"
        Me.lblTotalPhones.Size = New System.Drawing.Size(62, 18)
        Me.lblTotalPhones.TabIndex = 21
        Me.lblTotalPhones.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTotalPrice
        '
        Me.lblTotalPrice.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.lblTotalPrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTotalPrice.Location = New System.Drawing.Point(508, 253)
        Me.lblTotalPrice.Name = "lblTotalPrice"
        Me.lblTotalPrice.Size = New System.Drawing.Size(62, 17)
        Me.lblTotalPrice.TabIndex = 22
        '
        'Pb1
        '
        Me.Pb1.BackColor = System.Drawing.Color.Transparent
        Me.Pb1.Image = CType(resources.GetObject("Pb1.Image"), System.Drawing.Image)
        Me.Pb1.Location = New System.Drawing.Point(36, 12)
        Me.Pb1.Name = "Pb1"
        Me.Pb1.Size = New System.Drawing.Size(69, 64)
        Me.Pb1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Pb1.TabIndex = 23
        Me.Pb1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Trebuchet MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(14, 475)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(276, 18)
        Me.Label1.TabIndex = 24
        Me.Label1.Text = "Created and Designed by Robin Joshua L. Tan"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Trebuchet MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(296, 475)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(55, 18)
        Me.Label2.TabIndex = 25
        Me.Label2.Text = "3ITSE01"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Trebuchet MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(357, 475)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(102, 18)
        Me.Label3.TabIndex = 26
        Me.Label3.Text = "T 9:00-12:00pm"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Trebuchet MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(465, 475)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(119, 18)
        Me.Label4.TabIndex = 27
        Me.Label4.Text = "September 6, 2016"
        '
        'Pan1
        '
        Me.Pan1.BackColor = System.Drawing.Color.Transparent
        Me.Pan1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Pan1.Controls.Add(Me.lblMessage)
        Me.Pan1.Location = New System.Drawing.Point(25, 287)
        Me.Pan1.Name = "Pan1"
        Me.Pan1.Size = New System.Drawing.Size(559, 169)
        Me.Pan1.TabIndex = 28
        '
        'lblMessage
        '
        Me.lblMessage.AutoSize = True
        Me.lblMessage.BackColor = System.Drawing.Color.Transparent
        Me.lblMessage.Font = New System.Drawing.Font("Trebuchet MS", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMessage.Location = New System.Drawing.Point(106, 50)
        Me.lblMessage.Name = "lblMessage"
        Me.lblMessage.Size = New System.Drawing.Size(0, 37)
        Me.lblMessage.TabIndex = 16
        Me.lblMessage.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Transparent
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.BtnClear)
        Me.Panel1.Controls.Add(Me.BtnCal)
        Me.Panel1.Controls.Add(Me.BtnExit)
        Me.Panel1.Location = New System.Drawing.Point(417, 82)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(167, 134)
        Me.Panel1.TabIndex = 29
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Transparent
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel2.Controls.Add(Me.TxtCity)
        Me.Panel2.Controls.Add(Me.TxtName)
        Me.Panel2.Controls.Add(Me.TxtAddress)
        Me.Panel2.Controls.Add(Me.TxtState)
        Me.Panel2.Controls.Add(Me.TxtZIP)
        Me.Panel2.Controls.Add(Me.lblName)
        Me.Panel2.Controls.Add(Me.lblAddress)
        Me.Panel2.Controls.Add(Me.lblCity)
        Me.Panel2.Controls.Add(Me.lblState)
        Me.Panel2.Controls.Add(Me.lblZIP)
        Me.Panel2.Location = New System.Drawing.Point(25, 82)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(318, 134)
        Me.Panel2.TabIndex = 30
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(596, 502)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Pan1)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Pb1)
        Me.Controls.Add(Me.lblTotalPrice)
        Me.Controls.Add(Me.lblTotalPhones)
        Me.Controls.Add(Me.lblTotalPhonesN)
        Me.Controls.Add(Me.lblPinkPhones)
        Me.Controls.Add(Me.lblBluePhones)
        Me.Controls.Add(Me.lblTotalPriceN)
        Me.Controls.Add(Me.lblHeader)
        Me.Controls.Add(Me.TxtPinkPhones)
        Me.Controls.Add(Me.TxtBluePhones)
        Me.DoubleBuffered = True
        Me.Name = "Form1"
        Me.Text = "Playtime Cellular"
        CType(Me.Pb1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Pan1.ResumeLayout(False)
        Me.Pan1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents BtnCal As System.Windows.Forms.Button
    Friend WithEvents BtnClear As System.Windows.Forms.Button
    Friend WithEvents BtnExit As System.Windows.Forms.Button
    Friend WithEvents TxtName As System.Windows.Forms.TextBox
    Friend WithEvents TxtAddress As System.Windows.Forms.TextBox
    Friend WithEvents TxtCity As System.Windows.Forms.TextBox
    Friend WithEvents TxtState As System.Windows.Forms.TextBox
    Friend WithEvents TxtZIP As System.Windows.Forms.TextBox
    Friend WithEvents TxtBluePhones As System.Windows.Forms.TextBox
    Friend WithEvents TxtPinkPhones As System.Windows.Forms.TextBox
    Friend WithEvents lblHeader As System.Windows.Forms.Label
    Friend WithEvents lblName As System.Windows.Forms.Label
    Friend WithEvents lblAddress As System.Windows.Forms.Label
    Friend WithEvents lblCity As System.Windows.Forms.Label
    Friend WithEvents lblState As System.Windows.Forms.Label
    Friend WithEvents lblZIP As System.Windows.Forms.Label
    Friend WithEvents lblTotalPriceN As System.Windows.Forms.Label
    Friend WithEvents lblBluePhones As System.Windows.Forms.Label
    Friend WithEvents lblPinkPhones As System.Windows.Forms.Label
    Friend WithEvents lblTotalPhonesN As System.Windows.Forms.Label
    Friend WithEvents lblTotalPhones As System.Windows.Forms.Label
    Friend WithEvents lblTotalPrice As System.Windows.Forms.Label
    Friend WithEvents Pb1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Pan1 As System.Windows.Forms.Panel
    Friend WithEvents lblMessage As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel

End Class
