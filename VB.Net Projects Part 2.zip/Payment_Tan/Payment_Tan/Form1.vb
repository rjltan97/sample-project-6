﻿'Program: Payment Application
'Purpose: To Calculate Monthly Pay
'Programmer: Robin Joshua L. Tan on 9/27/2016

Option Explicit On
Option Infer Off
Option Strict On

Public Class Form1

    Private Sub btnCal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCal.Click
        Const strMSG As String = "The term must be greater than or equal to 1."
        Dim dblPrincipal As Double
        Dim dblRate As Double
        Dim dblTerm As Double
        Dim dblMonthlyPayment As Double


        Double.TryParse(txtPrincipal.Text, dblPrincipal)
        Double.TryParse(txtRate.Text, dblRate)
        Double.TryParse(txtTerm.Text, dblTerm)

        If dblRate >= 1 Then
            dblRate = dblRate / 100
        End If

        If dblTerm >= 1 Then
            dblMonthlyPayment = -Financial.Pmt(dblRate / 12, dblTerm * 12, dblPrincipal)
            lblDisplayPayment.Text = dblMonthlyPayment.ToString("C2")
        Else
            MessageBox.Show(strMSG, "Payroll", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            txtTerm.Text = String.Empty
        End If

    End Sub

    Private Sub ClearValues(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtPrincipal.TextChanged, txtRate.TextChanged, txtTerm.TextChanged
        lblDisplayPayment.Text = String.Empty
        txtPrincipal.Focus()
    End Sub

    Private Sub CancelKeys(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtPrincipal.KeyPress, txtRate.KeyPress, txtTerm.KeyPress
        If (e.KeyChar < "0" OrElse e.KeyChar > "9") AndAlso
            e.KeyChar <> "." AndAlso
            e.KeyChar <> ControlChars.Back Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtPrincipal_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtPrincipal.Enter
        txtPrincipal.SelectAll()
    End Sub

    Private Sub txtRate_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtRate.Enter
        txtRate.SelectAll()
    End Sub

    Private Sub txtTerm_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtTerm.Enter
        txtTerm.SelectAll()
    End Sub
    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
