﻿'Program: Movie Database
'Purpose: Movie Database
'Programmer: Robin Joshua L. Tan on November 29, 2016

Option Infer Off
Option Strict On
Option Explicit On
Public Class frmMain

    Private Sub frmMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'MoviesDataSet.tblMovies' table. You can move, or remove it, as needed.
        Me.TblMoviesTableAdapter.Fill(Me.MoviesDataSet.tblMovies)
        TblMoviesBindingSource.Sort = "YearProduced"

    End Sub

    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        If txtYear.Text.Trim = String.Empty Then
            MessageBox.Show("Please Enter the Required Fields", "Add Movies", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Else
            Dim intYear As Integer
            Dim intRate As Integer
            Integer.TryParse(txtRate.Text, intRate)
            Integer.TryParse(txtYear.Text, intYear)
            TblMoviesTableAdapter.Insert(intYear, txtMovie.Text, txtPC.Text, txtDir.Text, txtProd.Text, txtCast.Text, txtSound.Text, txtGenre.Text, intRate)
            TblMoviesTableAdapter.Fill(MoviesDataSet.tblMovies)
            MessageBox.Show("Movie Added", "Add Movies", MessageBoxButtons.OK, MessageBoxIcon.Information)

            txtCast.Text = String.Empty
            txtDir.Text = String.Empty
            txtProd.Text = String.Empty
            txtPC.Text = String.Empty
            txtRate.Text = String.Empty
            txtMovie.Text = String.Empty
            txtSound.Text = String.Empty
            txtGenre.Text = String.Empty
        End If
    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        If txtDelYear.Text = "" Then
            MessageBox.Show("Please Enter the Required Fields", "Delete Movies", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Else
            Dim dlgButton As DialogResult
            dlgButton = MessageBox.Show("Delete Movie?" & txtDelYear.Text & "?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation)
            Dim intYear As Integer
            Dim intRate As Integer
            Integer.TryParse(txtRate.Text, intRate)
            Integer.TryParse(txtDelYear.Text, intYear)
            TblMoviesTableAdapter.DeleteQuery(intYear)
            TblMoviesTableAdapter.Fill(MoviesDataSet.tblMovies)
            MessageBox.Show("Movie Deleted", "Delete Movies", MessageBoxButtons.OK, MessageBoxIcon.Information)

        End If
    End Sub
    Private Sub txtYear_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtYear.Enter
        txtYear.SelectAll()
    End Sub

    Private Sub txtSound_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtSound.Enter
        txtSound.SelectAll()
    End Sub

    Private Sub txtMovie_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtMovie.Enter
        txtMovie.SelectAll()
    End Sub

    Private Sub txtDelYear_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtDelYear.Enter
        txtDelYear.SelectAll()
    End Sub



    Private Sub txtYear_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtYear.KeyPress, txtDelYear.KeyPress
        If (e.KeyChar < "0" OrElse e.KeyChar > "9") AndAlso e.KeyChar <> ControlChars.Back Then
            e.Handled = True
        End If

    End Sub

    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub txtCast_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtCast.Enter
        txtCast.SelectAll()
    End Sub

    Private Sub txtDir_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtDir.Enter
        txtDir.SelectAll()
    End Sub

    Private Sub txtProd_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtProd.Enter
        txtProd.SelectAll()
    End Sub

    Private Sub txtPC_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtPC.Enter
        txtPC.SelectAll()
    End Sub

    Private Sub txtRate_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtRate.Enter
        txtRate.SelectAll()
    End Sub

    Private Sub txtGenre_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtGenre.Enter
        txtGenre.SelectAll()
    End Sub

    Private Sub BindingNavigatorAddNewItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BindingNavigatorAddNewItem.Click
        If txtYear.Text.Trim = String.Empty Then
            MessageBox.Show("Please Enter the Required Fields", "Add Movies", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Else
            Dim intYear As Integer
            Dim intRate As Integer
            Integer.TryParse(txtRate.Text, intRate)
            Integer.TryParse(txtYear.Text, intYear)
            TblMoviesTableAdapter.Insert(intYear, txtMovie.Text, txtPC.Text, txtDir.Text, txtProd.Text, txtCast.Text, txtSound.Text, txtGenre.Text, intRate)
            TblMoviesTableAdapter.Fill(MoviesDataSet.tblMovies)
            MessageBox.Show("Movie Added", "Add Movies", MessageBoxButtons.OK, MessageBoxIcon.Information)

            txtCast.Text = String.Empty
            txtDir.Text = String.Empty
            txtProd.Text = String.Empty
            txtPC.Text = String.Empty
            txtRate.Text = String.Empty
            txtMovie.Text = String.Empty
            txtSound.Text = String.Empty
            txtGenre.Text = String.Empty
        End If
    End Sub

    Private Sub btnSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearch.Click
        If txtSearch.Text = String.Empty Then
            MessageBox.Show("Please Enter the Required Fields", "Search Movies", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Else
            Dim intYear As Integer
            Integer.TryParse(txtSearch.Text, intYear)
            TblMoviesTableAdapter.SearchQuery(MoviesDataSet.tblMovies, intYear)

        End If
    End Sub

    Private Sub UpdateMoviesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UpdateMoviesToolStripMenuItem.Click

    End Sub

    Private Sub EditMoviesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EditMoviesToolStripMenuItem.Click
        DataGridView1.ReadOnly = False
    End Sub

    Private Sub ByYearToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ByYearToolStripMenuItem.Click
        TblMoviesBindingSource.Sort = "YearProduced"
    End Sub

    Private Sub ByMovieToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ByMovieToolStripMenuItem.Click
        TblMoviesBindingSource.Sort = "MovieName"
    End Sub

    Private Sub ByProductionCompanyToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ByProductionCompanyToolStripMenuItem.Click
        TblMoviesBindingSource.Sort = "ProductionCompany"
    End Sub

    Private Sub ByDirectorToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ByDirectorToolStripMenuItem.Click
        TblMoviesBindingSource.Sort = "Director"
    End Sub

    Private Sub ByProducerToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ByProducerToolStripMenuItem.Click
        TblMoviesBindingSource.Sort = "Producer"
    End Sub

    Private Sub ByCastToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ByCastToolStripMenuItem.Click
        TblMoviesBindingSource.Sort = "Cast"
    End Sub

    Private Sub BySoundtrackToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BySoundtrackToolStripMenuItem.Click
        TblMoviesBindingSource.Sort = "Soundtrack"
    End Sub

    Private Sub ByGenreToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ByGenreToolStripMenuItem.Click
        TblMoviesBindingSource.Sort = "Genre"
    End Sub

    Private Sub ByRatingToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ByRatingToolStripMenuItem.Click
        TblMoviesBindingSource.Sort = "Rating"
    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub ViewAllMoviesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ViewAllMoviesToolStripMenuItem.Click
        TblMoviesTableAdapter.Fill(MoviesDataSet.tblMovies)
    End Sub

    Private Sub txtSearch_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtSearch.TextChanged
        TblMoviesTableAdapter.Fill(MoviesDataSet.tblMovies)
    End Sub

    Private Sub SaveEditedStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveEditedStripMenuItem1.Click
        TblMoviesTableAdapter.Update(MoviesDataSet.tblMovies)
        MessageBox.Show("Changes Saved", "Edit Movies", MessageBoxButtons.OK, MessageBoxIcon.Information)
        DataGridView1.ReadOnly = True
    End Sub
End Class
