﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.pnlGrade = New System.Windows.Forms.Panel()
        Me.lblGrade = New System.Windows.Forms.Label()
        Me.rdGrade2 = New System.Windows.Forms.RadioButton()
        Me.rdGrade1 = New System.Windows.Forms.RadioButton()
        Me.pnlOperation = New System.Windows.Forms.Panel()
        Me.lblOperation = New System.Windows.Forms.Label()
        Me.rdSubtraction = New System.Windows.Forms.RadioButton()
        Me.rdAddition = New System.Windows.Forms.RadioButton()
        Me.pnlButton = New System.Windows.Forms.Panel()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnCheck = New System.Windows.Forms.Button()
        Me.chkSummary = New System.Windows.Forms.CheckBox()
        Me.lblRndm1 = New System.Windows.Forms.Label()
        Me.lblRndm2 = New System.Windows.Forms.Label()
        Me.txtAns = New System.Windows.Forms.TextBox()
        Me.grpSummary = New System.Windows.Forms.Panel()
        Me.lblincorr = New System.Windows.Forms.Label()
        Me.lblcorr = New System.Windows.Forms.Label()
        Me.lblIncorrect = New System.Windows.Forms.Label()
        Me.lblCorrect = New System.Windows.Forms.Label()
        Me.pbEquals = New System.Windows.Forms.PictureBox()
        Me.pbOperation = New System.Windows.Forms.PictureBox()
        Me.pbResult = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.pbPlus = New System.Windows.Forms.PictureBox()
        Me.pbMinus = New System.Windows.Forms.PictureBox()
        Me.pbSmile = New System.Windows.Forms.PictureBox()
        Me.pbSad = New System.Windows.Forms.PictureBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.pnlGrade.SuspendLayout()
        Me.pnlOperation.SuspendLayout()
        Me.pnlButton.SuspendLayout()
        Me.grpSummary.SuspendLayout()
        CType(Me.pbEquals, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbOperation, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbResult, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbPlus, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbMinus, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbSmile, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbSad, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pnlGrade
        '
        Me.pnlGrade.BackColor = System.Drawing.Color.Transparent
        Me.pnlGrade.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pnlGrade.Controls.Add(Me.lblGrade)
        Me.pnlGrade.Controls.Add(Me.rdGrade2)
        Me.pnlGrade.Controls.Add(Me.rdGrade1)
        Me.pnlGrade.Location = New System.Drawing.Point(12, 173)
        Me.pnlGrade.Name = "pnlGrade"
        Me.pnlGrade.Size = New System.Drawing.Size(189, 114)
        Me.pnlGrade.TabIndex = 0
        '
        'lblGrade
        '
        Me.lblGrade.AutoSize = True
        Me.lblGrade.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGrade.Location = New System.Drawing.Point(19, 19)
        Me.lblGrade.Name = "lblGrade"
        Me.lblGrade.Size = New System.Drawing.Size(56, 18)
        Me.lblGrade.TabIndex = 2
        Me.lblGrade.Text = "Grade"
        '
        'rdGrade2
        '
        Me.rdGrade2.AutoSize = True
        Me.rdGrade2.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdGrade2.Location = New System.Drawing.Point(22, 71)
        Me.rdGrade2.Name = "rdGrade2"
        Me.rdGrade2.Size = New System.Drawing.Size(123, 21)
        Me.rdGrade2.TabIndex = 2
        Me.rdGrade2.Text = "Grade &2 (10-99)"
        Me.rdGrade2.UseVisualStyleBackColor = True
        '
        'rdGrade1
        '
        Me.rdGrade1.AutoSize = True
        Me.rdGrade1.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdGrade1.Location = New System.Drawing.Point(22, 48)
        Me.rdGrade1.Name = "rdGrade1"
        Me.rdGrade1.Size = New System.Drawing.Size(116, 21)
        Me.rdGrade1.TabIndex = 1
        Me.rdGrade1.Text = "Grade &1 (1-10)"
        Me.rdGrade1.UseVisualStyleBackColor = True
        '
        'pnlOperation
        '
        Me.pnlOperation.BackColor = System.Drawing.Color.Transparent
        Me.pnlOperation.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pnlOperation.Controls.Add(Me.lblOperation)
        Me.pnlOperation.Controls.Add(Me.rdSubtraction)
        Me.pnlOperation.Controls.Add(Me.rdAddition)
        Me.pnlOperation.Location = New System.Drawing.Point(207, 173)
        Me.pnlOperation.Name = "pnlOperation"
        Me.pnlOperation.Size = New System.Drawing.Size(189, 114)
        Me.pnlOperation.TabIndex = 1
        '
        'lblOperation
        '
        Me.lblOperation.AutoSize = True
        Me.lblOperation.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOperation.Location = New System.Drawing.Point(15, 19)
        Me.lblOperation.Name = "lblOperation"
        Me.lblOperation.Size = New System.Drawing.Size(83, 18)
        Me.lblOperation.TabIndex = 3
        Me.lblOperation.Text = "Operation"
        '
        'rdSubtraction
        '
        Me.rdSubtraction.AutoSize = True
        Me.rdSubtraction.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdSubtraction.Location = New System.Drawing.Point(18, 71)
        Me.rdSubtraction.Name = "rdSubtraction"
        Me.rdSubtraction.Size = New System.Drawing.Size(100, 21)
        Me.rdSubtraction.TabIndex = 4
        Me.rdSubtraction.TabStop = True
        Me.rdSubtraction.Text = "&Subtraction"
        Me.rdSubtraction.UseVisualStyleBackColor = True
        '
        'rdAddition
        '
        Me.rdAddition.AutoSize = True
        Me.rdAddition.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdAddition.Location = New System.Drawing.Point(18, 48)
        Me.rdAddition.Name = "rdAddition"
        Me.rdAddition.Size = New System.Drawing.Size(81, 21)
        Me.rdAddition.TabIndex = 3
        Me.rdAddition.TabStop = True
        Me.rdAddition.Text = "&Addition"
        Me.rdAddition.UseVisualStyleBackColor = True
        '
        'pnlButton
        '
        Me.pnlButton.BackColor = System.Drawing.Color.Transparent
        Me.pnlButton.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pnlButton.Controls.Add(Me.btnExit)
        Me.pnlButton.Controls.Add(Me.btnCheck)
        Me.pnlButton.Location = New System.Drawing.Point(431, 12)
        Me.pnlButton.Name = "pnlButton"
        Me.pnlButton.Size = New System.Drawing.Size(145, 118)
        Me.pnlButton.TabIndex = 4
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(22, 80)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(96, 23)
        Me.btnExit.TabIndex = 8
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnCheck
        '
        Me.btnCheck.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCheck.Location = New System.Drawing.Point(22, 51)
        Me.btnCheck.Name = "btnCheck"
        Me.btnCheck.Size = New System.Drawing.Size(96, 23)
        Me.btnCheck.TabIndex = 6
        Me.btnCheck.Text = "&Check Answer"
        Me.btnCheck.UseVisualStyleBackColor = True
        '
        'chkSummary
        '
        Me.chkSummary.AutoSize = True
        Me.chkSummary.BackColor = System.Drawing.Color.Transparent
        Me.chkSummary.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkSummary.Location = New System.Drawing.Point(431, 146)
        Me.chkSummary.Name = "chkSummary"
        Me.chkSummary.Size = New System.Drawing.Size(135, 21)
        Me.chkSummary.TabIndex = 7
        Me.chkSummary.Text = "&Display Summary"
        Me.chkSummary.UseVisualStyleBackColor = False
        '
        'lblRndm1
        '
        Me.lblRndm1.BackColor = System.Drawing.Color.White
        Me.lblRndm1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblRndm1.Location = New System.Drawing.Point(12, 78)
        Me.lblRndm1.Name = "lblRndm1"
        Me.lblRndm1.Size = New System.Drawing.Size(60, 39)
        Me.lblRndm1.TabIndex = 4
        Me.lblRndm1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblRndm2
        '
        Me.lblRndm2.BackColor = System.Drawing.Color.White
        Me.lblRndm2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblRndm2.Location = New System.Drawing.Point(128, 78)
        Me.lblRndm2.Name = "lblRndm2"
        Me.lblRndm2.Size = New System.Drawing.Size(60, 39)
        Me.lblRndm2.TabIndex = 5
        Me.lblRndm2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtAns
        '
        Me.txtAns.Location = New System.Drawing.Point(257, 88)
        Me.txtAns.Name = "txtAns"
        Me.txtAns.Size = New System.Drawing.Size(56, 20)
        Me.txtAns.TabIndex = 3
        Me.txtAns.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'grpSummary
        '
        Me.grpSummary.BackColor = System.Drawing.Color.Transparent
        Me.grpSummary.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.grpSummary.Controls.Add(Me.lblincorr)
        Me.grpSummary.Controls.Add(Me.lblcorr)
        Me.grpSummary.Controls.Add(Me.lblIncorrect)
        Me.grpSummary.Controls.Add(Me.lblCorrect)
        Me.grpSummary.Location = New System.Drawing.Point(431, 173)
        Me.grpSummary.Name = "grpSummary"
        Me.grpSummary.Size = New System.Drawing.Size(145, 114)
        Me.grpSummary.TabIndex = 7
        Me.grpSummary.Visible = False
        '
        'lblincorr
        '
        Me.lblincorr.AutoSize = True
        Me.lblincorr.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblincorr.Location = New System.Drawing.Point(61, 69)
        Me.lblincorr.Name = "lblincorr"
        Me.lblincorr.Size = New System.Drawing.Size(65, 17)
        Me.lblincorr.TabIndex = 11
        Me.lblincorr.Text = "Incorrect"
        '
        'lblcorr
        '
        Me.lblcorr.AutoSize = True
        Me.lblcorr.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcorr.Location = New System.Drawing.Point(61, 27)
        Me.lblcorr.Name = "lblcorr"
        Me.lblcorr.Size = New System.Drawing.Size(57, 17)
        Me.lblcorr.TabIndex = 10
        Me.lblcorr.Text = "Correct"
        '
        'lblIncorrect
        '
        Me.lblIncorrect.BackColor = System.Drawing.Color.White
        Me.lblIncorrect.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblIncorrect.Location = New System.Drawing.Point(13, 61)
        Me.lblIncorrect.Name = "lblIncorrect"
        Me.lblIncorrect.Size = New System.Drawing.Size(42, 28)
        Me.lblIncorrect.TabIndex = 9
        Me.lblIncorrect.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblCorrect
        '
        Me.lblCorrect.BackColor = System.Drawing.Color.White
        Me.lblCorrect.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCorrect.Location = New System.Drawing.Point(13, 19)
        Me.lblCorrect.Name = "lblCorrect"
        Me.lblCorrect.Size = New System.Drawing.Size(42, 28)
        Me.lblCorrect.TabIndex = 8
        Me.lblCorrect.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pbEquals
        '
        Me.pbEquals.BackColor = System.Drawing.Color.Transparent
        Me.pbEquals.Image = CType(resources.GetObject("pbEquals.Image"), System.Drawing.Image)
        Me.pbEquals.Location = New System.Drawing.Point(207, 75)
        Me.pbEquals.Name = "pbEquals"
        Me.pbEquals.Size = New System.Drawing.Size(44, 42)
        Me.pbEquals.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbEquals.TabIndex = 9
        Me.pbEquals.TabStop = False
        '
        'pbOperation
        '
        Me.pbOperation.BackColor = System.Drawing.Color.Transparent
        Me.pbOperation.Location = New System.Drawing.Point(78, 75)
        Me.pbOperation.Name = "pbOperation"
        Me.pbOperation.Size = New System.Drawing.Size(44, 42)
        Me.pbOperation.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbOperation.TabIndex = 10
        Me.pbOperation.TabStop = False
        '
        'pbResult
        '
        Me.pbResult.BackColor = System.Drawing.Color.Transparent
        Me.pbResult.Location = New System.Drawing.Point(319, 78)
        Me.pbResult.Name = "pbResult"
        Me.pbResult.Size = New System.Drawing.Size(44, 42)
        Me.pbResult.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbResult.TabIndex = 11
        Me.pbResult.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Lucida Console", 21.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(7, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(301, 29)
        Me.Label1.TabIndex = 12
        Me.Label1.Text = "Math Application"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pbPlus
        '
        Me.pbPlus.BackColor = System.Drawing.Color.Transparent
        Me.pbPlus.Image = CType(resources.GetObject("pbPlus.Image"), System.Drawing.Image)
        Me.pbPlus.Location = New System.Drawing.Point(12, 327)
        Me.pbPlus.Name = "pbPlus"
        Me.pbPlus.Size = New System.Drawing.Size(44, 42)
        Me.pbPlus.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbPlus.TabIndex = 13
        Me.pbPlus.TabStop = False
        Me.pbPlus.Visible = False
        '
        'pbMinus
        '
        Me.pbMinus.BackColor = System.Drawing.Color.Transparent
        Me.pbMinus.Image = CType(resources.GetObject("pbMinus.Image"), System.Drawing.Image)
        Me.pbMinus.Location = New System.Drawing.Point(62, 327)
        Me.pbMinus.Name = "pbMinus"
        Me.pbMinus.Size = New System.Drawing.Size(44, 42)
        Me.pbMinus.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbMinus.TabIndex = 14
        Me.pbMinus.TabStop = False
        Me.pbMinus.Visible = False
        '
        'pbSmile
        '
        Me.pbSmile.BackColor = System.Drawing.Color.Transparent
        Me.pbSmile.Image = CType(resources.GetObject("pbSmile.Image"), System.Drawing.Image)
        Me.pbSmile.Location = New System.Drawing.Point(115, 327)
        Me.pbSmile.Name = "pbSmile"
        Me.pbSmile.Size = New System.Drawing.Size(44, 42)
        Me.pbSmile.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbSmile.TabIndex = 15
        Me.pbSmile.TabStop = False
        Me.pbSmile.Visible = False
        '
        'pbSad
        '
        Me.pbSad.BackColor = System.Drawing.Color.Transparent
        Me.pbSad.Image = CType(resources.GetObject("pbSad.Image"), System.Drawing.Image)
        Me.pbSad.Location = New System.Drawing.Point(165, 327)
        Me.pbSad.Name = "pbSad"
        Me.pbSad.Size = New System.Drawing.Size(44, 42)
        Me.pbSad.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbSad.TabIndex = 16
        Me.pbSad.TabStop = False
        Me.pbSad.Visible = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(62, 295)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(149, 18)
        Me.Label2.TabIndex = 17
        Me.Label2.Text = "Robin Joshua L. Tan"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(214, 295)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(58, 18)
        Me.Label3.TabIndex = 18
        Me.Label3.Text = "3ITSE01"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(280, 295)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(102, 18)
        Me.Label4.TabIndex = 19
        Me.Label4.Text = "T/F 9:00-12:00"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(388, 295)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(130, 18)
        Me.Label5.TabIndex = 20
        Me.Label5.Text = "October 11, 2016"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(589, 322)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.pbSad)
        Me.Controls.Add(Me.pbSmile)
        Me.Controls.Add(Me.pbMinus)
        Me.Controls.Add(Me.pbPlus)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.pbResult)
        Me.Controls.Add(Me.pbOperation)
        Me.Controls.Add(Me.pbEquals)
        Me.Controls.Add(Me.grpSummary)
        Me.Controls.Add(Me.txtAns)
        Me.Controls.Add(Me.lblRndm2)
        Me.Controls.Add(Me.lblRndm1)
        Me.Controls.Add(Me.chkSummary)
        Me.Controls.Add(Me.pnlButton)
        Me.Controls.Add(Me.pnlOperation)
        Me.Controls.Add(Me.pnlGrade)
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Math Application"
        Me.pnlGrade.ResumeLayout(False)
        Me.pnlGrade.PerformLayout()
        Me.pnlOperation.ResumeLayout(False)
        Me.pnlOperation.PerformLayout()
        Me.pnlButton.ResumeLayout(False)
        Me.grpSummary.ResumeLayout(False)
        Me.grpSummary.PerformLayout()
        CType(Me.pbEquals, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbOperation, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbResult, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbPlus, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbMinus, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbSmile, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbSad, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents pnlGrade As System.Windows.Forms.Panel
    Friend WithEvents lblGrade As System.Windows.Forms.Label
    Friend WithEvents rdGrade2 As System.Windows.Forms.RadioButton
    Friend WithEvents rdGrade1 As System.Windows.Forms.RadioButton
    Friend WithEvents pnlOperation As System.Windows.Forms.Panel
    Friend WithEvents lblOperation As System.Windows.Forms.Label
    Friend WithEvents rdSubtraction As System.Windows.Forms.RadioButton
    Friend WithEvents rdAddition As System.Windows.Forms.RadioButton
    Friend WithEvents pnlButton As System.Windows.Forms.Panel
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents btnCheck As System.Windows.Forms.Button
    Friend WithEvents chkSummary As System.Windows.Forms.CheckBox
    Friend WithEvents lblRndm1 As System.Windows.Forms.Label
    Friend WithEvents lblRndm2 As System.Windows.Forms.Label
    Friend WithEvents txtAns As System.Windows.Forms.TextBox
    Friend WithEvents grpSummary As System.Windows.Forms.Panel
    Friend WithEvents lblincorr As System.Windows.Forms.Label
    Friend WithEvents lblcorr As System.Windows.Forms.Label
    Friend WithEvents lblIncorrect As System.Windows.Forms.Label
    Friend WithEvents lblCorrect As System.Windows.Forms.Label
    Friend WithEvents pbEquals As System.Windows.Forms.PictureBox
    Friend WithEvents pbOperation As System.Windows.Forms.PictureBox
    Friend WithEvents pbResult As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents pbPlus As System.Windows.Forms.PictureBox
    Friend WithEvents pbMinus As System.Windows.Forms.PictureBox
    Friend WithEvents pbSmile As System.Windows.Forms.PictureBox
    Friend WithEvents pbSad As System.Windows.Forms.PictureBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label

End Class
