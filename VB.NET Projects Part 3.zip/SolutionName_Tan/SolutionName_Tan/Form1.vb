﻿'PROJECT DETAILS'
'Name: Martha Arenso'
'Purpose: Inventory Application'
'Programmer: Robin Joshua L. Tan'
Public Class frmMain

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnCal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCal.Click
        lblTotalVersion.Text = Val(txtHardVer.Text) + Val(txtPaperVer.Text)
        lblPValue.Text = Val(txtPaperVer.Text) * Val(TxtPCost.Text)
        lblHValue.Text = Val(txtHardVer.Text) * Val(TxtHCost.Text)
        lblTValue.Text = Val(lblPValue.Text) + Val(lblHValue.Text)
        lblPValue.Text = Format(lblPValue.Text, "Currency")
        lblHValue.Text = Format(lblHValue.Text, "Currency")
        lblTValue.Text = Format(lblTValue.Text, "Currency")
    End Sub

    Private Sub BtnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnClear.Click
        txtName.Clear()
        txtPaperVer.Clear()
        txtHardVer.Clear()
        TxtHCost.Clear()
        TxtPCost.Clear()
        lblTotalVersion.Text = ""
        lblPValue.Text = ""
        lblHValue.Text = ""
        lblTValue.Text = ""
        txtName.Focus()
    End Sub

    Private Sub BtnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnExit.Click
        Me.Close()
    End Sub
End Class
