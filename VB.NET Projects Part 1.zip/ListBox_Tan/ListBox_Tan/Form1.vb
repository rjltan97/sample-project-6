﻿'Program: List Box Selection
'Purpose: Create a List Box
'Programmer: Robin Joshua L. Tan on November 8, 2016

Option Infer Off
Option Strict On
Option Explicit On

Public Class Form1

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        lstCode.SelectedIndex = 0
        lstAnimals.SelectedIndex = 0
    End Sub
    Private Sub btnSingle_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSingle.Click
        lblResult.Text = lstNames.Text
    End Sub

    Private Sub btnMulti_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMulti.Click
        Dim intIndex As Integer

        Do While intIndex < lstNames.SelectedItems.Count
            lblResult.Text = lblResult.Text & _
                lstNames.SelectedItems(intIndex).ToString & ControlChars.NewLine
            intIndex += 1
        Loop
    End Sub

    Private Sub btnInsert_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInsert.Click
        lstNames.Items.Insert(3, "Robin")
        lstNames.Items.Insert(3, "Alyssa")
        lstNames.Items.Insert(3, "Marco")
        lstNames.Items.Insert(3, "Gelo")
        lstNames.Items.Insert(3, "Kate")
    End Sub

    Private Sub btnRemove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRemove.Click
        lstNames.Items.Remove("Robin")
    End Sub

    Private Sub btnRemoveAt_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRemoveAt.Click
        lstNames.Items.RemoveAt(1)
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        lstNames.Items.Clear()
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnCount_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCount.Click
        MsgBox("The number of Items is " & lstNames.Items.Count, MsgBoxStyle.Information, "Item Count")
    End Sub

    Private Sub lstNames_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstNames.SelectedIndexChanged
        lblResult.Text = ""
    End Sub
End Class
